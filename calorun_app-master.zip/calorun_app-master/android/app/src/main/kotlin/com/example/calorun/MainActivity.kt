package com.example.calorun

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
